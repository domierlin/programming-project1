package intersect;

import java.util.ArrayList;

public class Intersect {
	public static void main(String[] args) {
		
	
	//Arraylist#1
	ArrayList<Integer>list1= new ArrayList<Integer>();
	list1.add(1);list1.add(4); list1.add(8); list1.add(9);list1.add(11);list1.add(15);list1.add(17);
	list1.add(28);list1.add(41);list1.add(59);
	
	//Arraylist#2
	ArrayList<Integer>list2= new ArrayList<Integer>();
	list2.add(4);list2.add(7); list2.add(11);list2.add(17);list2.add(19);list2.add(20);list2.add(23);
	list2.add(28);list2.add(37);list2.add(59);list2.add(81);
	
	System.out.println(list1); System.out.println(list2);
	System.out.println("new List: " +intersect(list1, list2));
}
	
	public static ArrayList<Integer> intersect( ArrayList<Integer>list1, ArrayList<Integer>list2){
		
		ArrayList<Integer>list= new ArrayList<Integer>();
		
		if(list1.size()<list2.size()) {
			for (int i=0; i<list2.size(); i++) {
				int temp = list2.get(i);
				if (list1.contains(temp)) {
				list.add(temp);
			}
		}
	}
	
	
	if(list1.size()>list2.size()|| list1.size()==list2.size()) {
		for(int i=0; i<list1.size(); i++) {
			int temp= list1.get(i);
			if(list2.contains(temp)) {
				list.add(temp);
			}
		}
	}
	return list;
}
}